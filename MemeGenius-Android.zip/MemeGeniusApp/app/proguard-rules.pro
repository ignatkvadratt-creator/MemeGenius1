# Keep everything simple for WebView app
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
