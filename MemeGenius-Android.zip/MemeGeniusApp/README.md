# Meme Genius — Android APK

Готовый Android-проект (WebView), в который встроен твой HTML «Meme Genius».

## Что внутри
- Полностью рабочий WebView с поддержкой выбора фото (`<input type="file">`)
- Интернет-разрешение для Gemini API
- Тёмная тема под стиль приложения
- Иконка приложения
- Package: `com.memegenius.app`

## Как собрать APK

### Способ 1 (самый простой) — Android Studio
1. Скачай и установи [Android Studio](https://developer.android.com/studio)
2. Открой эту папку как проект (`File → Open`)
3. Дождись, пока Gradle синхронизируется
4. Подключи телефон или выбери эмулятор
5. Нажми **Run** (зелёный треугольник) или `Build → Build Bundle(s) / APK(s) → Build APK(s)`
6. Готовый APK будет в `app/build/outputs/apk/debug/app-debug.apk`

### Способ 2 — командная строка (если установлен Android SDK)
```bash
# В корне проекта
./gradlew assembleDebug
```
APK появится в `app/build/outputs/apk/debug/`

### Release APK (подписанный)
1. Создай keystore (один раз):
```bash
keytool -genkey -v -keystore meme-genius.keystore -alias meme -keyalg RSA -keysize 2048 -validity 10000
```
2. В `app/build.gradle` добавь блок `signingConfigs` и укажи путь к keystore
3. `./gradlew assembleRelease`

## Важно
- API-ключ Gemini пользователь вводит сам в приложении — он **не сохраняется** (как и в оригинальном HTML).
- Для публикации в Google Play нужно будет добавить Privacy Policy (т.к. используется API-ключ и фото).
- Если захочешь изменить название/package — правь `AndroidManifest.xml`, `build.gradle` и `strings.xml`.

Приятного использования!
